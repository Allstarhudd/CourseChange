package com.justusjoel.ui;

import com.justusjoel.dao.UserDAO;
import com.justusjoel.model.User;

public class LoginController {

    public void login(String username, String password) {
        UserDAO dao = new UserDAO();
        User user = dao.authenticate(username, password);

        if (user != null) {
            System.out.println("Login successful: " + user.getRole());
        } else {
            System.out.println("Invalid credentials");
        }
    }
}
