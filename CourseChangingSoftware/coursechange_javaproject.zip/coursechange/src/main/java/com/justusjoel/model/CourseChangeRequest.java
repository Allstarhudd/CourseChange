package com.justusjoel.model;

import java.time.LocalDateTime;

public class CourseChangeRequest {

    @SuppressWarnings("FieldMayBeFinal")
    private int requestId;
    @SuppressWarnings("FieldMayBeFinal")
    private int studentId;
    @SuppressWarnings("FieldMayBeFinal")
    private int oldCourseId;
    @SuppressWarnings("FieldMayBeFinal")
    private int newCourseId;
    @SuppressWarnings("FieldMayBeFinal")
    private String status;
    @SuppressWarnings("FieldMayBeFinal")
    private LocalDateTime requestDate;
    @SuppressWarnings("FieldMayBeFinal")
    private LocalDateTime decisionDate;
    @SuppressWarnings("FieldMayBeFinal")
    private String remarks;

    public CourseChangeRequest(int requestId, int studentId, int oldCourseId,
                               int newCourseId, String status, LocalDateTime requestDate,
                               LocalDateTime decisionDate, String remarks) {
        this.requestId = requestId;
        this.studentId = studentId;
        this.oldCourseId = oldCourseId;
        this.newCourseId = newCourseId;
        this.status = status;
        this.requestDate = requestDate;
        this.decisionDate = decisionDate;
        this.remarks = remarks;
    }

    public int getId() {
        return requestId;
    }

    public int getOldCourse() {
        return oldCourseId;
    }

    public int getNewCourse() {
        return newCourseId;
    }

    public int getStudentId() { 
        return studentId; 
    }
    
    public String getStatus() { 
        return status; 
    }
    
    public LocalDateTime getRequestDate() { 
        return requestDate; 
    }
    
    public LocalDateTime getDecisionDate() { 
        return decisionDate; 
    }
    
    public String getRemarks() { 
        return remarks; 
    }
}
